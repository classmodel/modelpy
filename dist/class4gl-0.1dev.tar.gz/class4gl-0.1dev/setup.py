from distutils.core import setup

setup(
        name='class4gl',
        version='0.1dev',
        packages=['lib','bin'],
        license='GPLv3 licence',
        long_description=open('README.md').read(),
)
