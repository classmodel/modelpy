from . import model,class4gl,interface_multi,data_air,data_global

__version__ = '0.1.0'

__author__ = 'Hendrik Wouters <hendrikwout@gmail.com>'

__all__ = []
